public interface ElectronicDevices{
	public void turnOn();
	public void turnOff();
}
