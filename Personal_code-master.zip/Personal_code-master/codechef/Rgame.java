import java.util.*;
import java.io.*;

public class Rgame{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int tc = sc.nextInt();
		int n = sc.nextInt();
		int sample[] = new int[n+1];

		for (int i=0; i<=n;  i++ ) {
			sample[i] = sc.nextInt();
		}

		
	}
}