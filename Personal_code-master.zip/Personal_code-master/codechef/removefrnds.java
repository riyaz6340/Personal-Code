import java.util.*;

class removefrnds {
    public static void main(String args[] ) throws Exception {
        Scanner sc = new Scanner(System.in);
        int tc=sc.nextInt();
        int i,j;
        
        
        for(i=0;i<tc;i++){
            int frds = sc.nextInt();
            int rmv = sc.nextInt();
            int pop[]=new int[frds];
            for(j=0;j<frds;j++){
                pop[j]=sc.nextInt();
            }
            for(j=0;j<=frds;j++){
                if(pop)
            }
        }
    }
}
